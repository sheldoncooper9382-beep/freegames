import left from './left';
import right from './right';
import down from './down';
import rotate from './rotate';
import space from './space';
import s from './s';
import r from './r';
import p from './p';

export default {
  left,
  down,
  rotate,
  right,
  space,
  r,
  p,
  s,
};
